Finished udacity stuff wk 9 as the last week hardly had any content.
missing report 9 and 10
missing SASS work which I had scheduled for wk 10

