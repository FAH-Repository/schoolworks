console.log('hello world');

function sayHi(name){
console.log('hi '+ name)
}
//some global tools
//console.log(); 
//setTimeout();
//clearTimeout();
//setInterval();
//clearInterval();
//sayHi('Forest');
//global is itself an object
//global.console.log
//var(s) are not added to global


/* 
var message = '';
console.log(global.message);
results undefined
*/




