its all in its own folder because i didnt date the work and it was all auto sorted alphabetically

exercism assignements come with test cases, but to use the cases you have to run npm test, 
which requires npm installed on each file or globably installed. ive installed it globally
but you may need to do the same if you want to run npm test


I used visual studio code for all works, if that matters
