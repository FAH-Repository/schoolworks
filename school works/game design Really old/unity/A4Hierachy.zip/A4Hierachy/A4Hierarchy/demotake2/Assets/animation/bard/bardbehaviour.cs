﻿using UnityEngine;
using System.Collections;

public class bardBehaviour : MonoBehaviour {
    public Animator bard;
    float LastPositionX;
    float LastPositionZ;
    public GameObject player;

    // Use this for initialization
    void Start() {
        bard = GetComponent<Animator>();

    }

    // Update is called once per frame
    void Update() {
        float x = player.transform.position.x;
        float z = player.transform.position.z;
        LastPositionX = transform.position.x;
        LastPositionZ = transform.position.z;
        //  public bool fup = Anim.bool("up");

        


        if (LastPositionZ > player.transform.position.z) {
            bard.SetBool("face up", false);
            bard.SetBool("face down", true);
            bard.SetBool("face left", false);
            bard.SetBool("face right", false);
        }

        if (LastPositionZ < player.transform.position.z) {
            bard.SetBool("face up", true);
            bard.SetBool("face down", false);
            bard.SetBool("face left", false);
            bard.SetBool("face right", false);
        }

        if (LastPositionX > player.transform.position.x) {
            bard.SetBool("face up", false);
            bard.SetBool("face down", false);
            bard.SetBool("face left", true);
            bard.SetBool("face right", false);
        }

        if (LastPositionX < player.transform.position.x) {
            bard.SetBool("face up", false);
            bard.SetBool("face down", false);
            bard.SetBool("face left", false);
            bard.SetBool("face right", true);
        }



        if (LastPositionZ > player.transform.position.z) {
            bard.SetBool("bard down", true);
        } else {
            bard.SetBool("bard down", false);
        }



        if (LastPositionZ < player.transform.position.z) {
            bard.SetBool("bard up", true);
        } else {
            bard.SetBool("bard up", false);
        }



        if (LastPositionX < player.transform.position.x) {
            bard.SetBool("bard right", true);

        } else {
            bard.SetBool("bard right", false);
        }



        if (LastPositionX > player.transform.position.x) {
            bard.SetBool("bard left", true);
        } else {
            bard.SetBool("bard left", false);
        }


    }
}
