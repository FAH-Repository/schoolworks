﻿using UnityEngine;
using System.Collections;

public class UseChest : MonoBehaviour
{
    public Animator anim;
    public float chestUseDis;
    public GameObject chest;
    public GameObject Player;



    // Use this for initialization
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {


        float distance = Vector3.Distance(chest.transform.position, Player.transform.position);
        if (distance <= chestUseDis && Input.GetKeyDown(KeyCode.E))
        {

            anim.SetBool("open", true);

        }
    }
}

