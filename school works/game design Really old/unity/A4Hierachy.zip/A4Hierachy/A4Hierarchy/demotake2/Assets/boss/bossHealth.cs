﻿using UnityEngine;
using System.Collections;

public class bossHealth : MonoBehaviour {

    public int maxhealth = 500;
    public int curhealth = 500;
    float restartTimer;
    public float restartDelay = 5f;
    public Animator anim;

    private GUIStyle currentStyle = null;
    public float healthBarLength;
    
    // Use this for initialization
    void Start()
    {
        healthBarLength = Screen.width / 2;
    }

    // Update is called once per frame
    void Update()
    {
        AddjustCurHealth(0);
    }

    void OnGUI()
    {
        InitStyles();


        GUI.Box(new Rect(350, 10, healthBarLength, 20), "Boss     " + curhealth + "/" + maxhealth, currentStyle);


    }
    private void InitStyles()
{
    if (currentStyle == null)
    {
        currentStyle = new GUIStyle(GUI.skin.box);
        currentStyle.normal.background = MakeTex(2, 2, new Color( 0, 1, 0, .5f));
    }
}
private Texture2D MakeTex(int width, int height, Color col)
{
    Color[] pix = new Color[width * height];
    for (int i = 0; i < pix.Length; ++i)
    {
        pix[i] = col;
    }
    Texture2D result = new Texture2D(width, height);
    result.SetPixels(pix);
    result.Apply();
    return result;
}
public void AddjustCurHealth(int adj)
    {


        curhealth += adj;

        if (curhealth < 1)
        {
            curhealth = 0;
        }
        if (curhealth > maxhealth)
        {
            curhealth = maxhealth;
        }
        if (maxhealth < 1)
        {
            maxhealth = 1;

        }
        if (curhealth <= 0)
        {
            //    anim.SetTrigger("dead");

        }
        if (curhealth <= 0)
        {
            anim.SetInteger("direction", 2);
            restartTimer += Time.deltaTime;
            if (restartTimer >= restartDelay)
            {
                Destroy(gameObject);
                Application.LoadLevel(5);

            }
        }

     
         healthBarLength = (Screen.width / 2) * (curhealth / (float)maxhealth);

    }
}

