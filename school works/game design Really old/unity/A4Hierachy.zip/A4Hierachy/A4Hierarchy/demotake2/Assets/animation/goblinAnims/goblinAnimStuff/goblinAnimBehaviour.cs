﻿using UnityEngine;
using System.Collections;

public class goblinAnimBehaviour : MonoBehaviour
{
    Animator anim;
    public Transform player;

    int lastDir = 2;
   
    // Use this for initialization
    void Start()
    {
        anim = GetComponent<Animator>();
        anim.SetBool("isWalking", false);
    }

    void setAnimDirection(int d) 
    {
        if (lastDir != d)
        {
            anim.SetInteger("direction", d);
            lastDir = d;
            anim.SetTrigger("confirm");
        }
    }

    // Update is called once per frame
    void Update()
    {
        Vector3 diff = player.position - transform.position;

        if (Mathf.Abs(diff.x) < Mathf.Abs(diff.z))
        {
            if (diff.z > 0)
            {
                setAnimDirection(0);
            }
            else
            {
                setAnimDirection(2);
            }
        }
        else 
        {
            if (diff.x > 0)
            {
                setAnimDirection(1);
            }
            else
            {
                setAnimDirection(3);
            }
        }
    }
}
//z up is positive
//x right is positive
