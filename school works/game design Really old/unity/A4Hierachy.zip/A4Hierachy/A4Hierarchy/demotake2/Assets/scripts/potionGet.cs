﻿using UnityEngine;
using System.Collections;



public class potionGet : MonoBehaviour {
    public int potionNum;


    // Use this for initialization
    void Start () {
       
	
	}
	
	// Update is called once per frame
	void Update () { 
if (Input.GetKey(KeyCode.E)) 
        {
            potionNum += 1;
        }

	
	}
}
