﻿using UnityEngine;
using System.Collections;

public class bossAttack : MonoBehaviour
{

    public GameObject target;
    public float attacktimer;
    public float cooldown;
    public Animator anim;
    int lastDir = 0;
   
    // Use this for initialization
    void Start()
    {
        attacktimer = 0;
        cooldown = 3.0f;
    }
   
        // Update is called once per frame
        void Update()
    {
        //
        if (attacktimer > 0)
        {
            attacktimer -= Time.deltaTime;
        }
        if (attacktimer < 0)
        {
            attacktimer = 0;
        }

        if (attacktimer == 0)
        {
           
            attack();
            
            attacktimer = cooldown;
           
        }

    }

    private void attack()
    {
       
        //calculates distance between it and player
        float distance = Vector3.Distance(target.transform.position, transform.position);

        Vector3 dir = (target.transform.position - transform.position).normalized;

        float direction = Vector3.Dot(dir, transform.forward);
        //limits range of attack
        // Debug.Log(distance);
        if (distance < .47f && (this.transform.position.z > target.transform.position.z))
        {
            //makes it so you have to face the enemy to attack

            anim.SetInteger("direction", 1);
            playerhealth ph = (playerhealth)target.GetComponent("playerhealth");
            ph.AddjustCurHealth(-11);
        }
        else
        {
            anim.SetInteger("direction", 0);

        }
    }
}
