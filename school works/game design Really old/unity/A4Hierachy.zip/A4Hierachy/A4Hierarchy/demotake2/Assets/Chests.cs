﻿using UnityEngine;
using System.Collections;


public class Chests : MonoBehaviour {
    public GameObject chest;
    public GameObject Player;
    public float chestUseDis;
    public GameObject potion;
    public Animator anim;
	// Use this for initialization
	void Start () {
	
	}

    // Update is called once per frame
    void Update() {
        float distance = Vector3.Distance(chest.transform.position, Player.transform.position);
        if (distance <= chestUseDis && Input.GetKeyDown(KeyCode.E))
        {

            potion.transform.position = chest.transform.position - new Vector3(0, 0, .2f);
            isOpen();

            anim.SetBool("open", true);
        }
    }
       public void isOpen() 
{
        float distance = Vector3.Distance(chest.transform.position, Player.transform.position);
        if (distance <= chestUseDis && Input.GetKeyDown(KeyCode.E))
        {
            
            anim.SetBool("open", true);

        }


    }
      

    }

