﻿var isQuit = false;
var isControls = false;


function OnMouseUp() {
    //is this quit
    if (isQuit == true) {
        //quit the game
        Application.Quit();
        
    }
    if (isControls == true) {
        Application.LoadLevel(4);


    }
        else {
            //load level
            Application.LoadLevel(2);
    }

    }



function Update() {
    //quit game if escape key is pressed
    if (Input.GetKey(KeyCode.Escape)) {
        Application.Quit();
    }

}

